﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hazi_dolgozat_urhajosjatek
{
    public partial class Form1 : Form
    {
        int pos = 0;
        bool jobbra = true;
        int elet = 3;
        int pontszam = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //timer növelés
            if (e.KeyCode==Keys.Add)
            {
                timer1.Interval /= 2;
                timer2.Interval /= 2;
                timer3.Interval /= 2;
            }

            //timer csökkentés
            if (e.KeyCode == Keys.Subtract)
            {
                timer1.Interval *= 2;
                timer2.Interval *= 2;
                timer3.Interval *= 2;
            }

            //indítás
            if (e.KeyCode==Keys.Enter)
            {
                label3.Visible = false;
                timer1.Start();
                timer2.Start();
                timer3.Start();
            }
            
            //mozgás
            if (e.KeyCode == Keys.A)
            {
                pburhajo.Location = new Point(pburhajo.Location.X - 10, pburhajo.Location.Y);
            }
            if (e.KeyCode == Keys.D)
            {
                pburhajo.Location = new Point(pburhajo.Location.X + 10, pburhajo.Location.Y);
            }

            //űrhajó mozgásának korlátozása
            if (pburhajo.Location.X<1)
            {
                pburhajo.Location = new Point(726, pburhajo.Location.Y);
            }
            if (pburhajo.Location.X>726)
            {
                pburhajo.Location = new Point(1, pburhajo.Location.Y);
            }

            lovedekell();
        }


        private void moveEnemy(int x)
        {
          //enemy mozgás
            pbEnemy1.Location = new Point(pbEnemy1.Location.X + x, pbEnemy1.Location.Y);
            pbEnemy2.Location = new Point(pbEnemy1.Location.X + x + 55, pbEnemy1.Location.Y);
            pbEnemy3.Location = new Point(pbEnemy1.Location.X + x + 2 * 55, pbEnemy1.Location.Y);
            pbEnemy4.Location = new Point(pbEnemy1.Location.X + x + 3 * 55, pbEnemy1.Location.Y);
            pbEnemy5.Location = new Point(pbEnemy1.Location.X + x + 4 * 55, pbEnemy1.Location.Y);
            pbEnemy6.Location = new Point(pbEnemy1.Location.X + x, pbEnemy1.Location.Y + 50);
            pbEnemy7.Location = new Point(pbEnemy1.Location.X + x + 55, pbEnemy1.Location.Y + 50);
            pbEnemy8.Location = new Point(pbEnemy1.Location.X + x + 2 * 55, pbEnemy1.Location.Y + 50);
            pbEnemy9.Location = new Point(pbEnemy1.Location.X + x + 3 * 55, pbEnemy1.Location.Y + 50);
            pbEnemy10.Location = new Point(pbEnemy1.Location.X + x + 4 * 55, pbEnemy1.Location.Y + 50);
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
           //enemy mozgás
            if (jobbra)
            {
                if (pos < 55)
                {
                    moveEnemy(5);
                    pos += 1;
                }
                else
                {
                    moveEnemy(-5);
                    pos -= 1;
                    jobbra = false;
                }
            }
            else
            {
                if (pos > -45)
                {
                    moveEnemy(-5);
                    pos -= 1;
                }
                else
                {
                    moveEnemy(5);
                    pos += 1;
                    jobbra = true;
                }
            }
        }

        private void enemyell(PictureBox pbEnemy)
        {
            //ha az űrhajólövedék eltalálja az enemyt akkor eltűnik, pontszám növekszik 10-zel,
            //és az űrhajólövedék visszakerül a az űrhajó pozíciójába
            if (urhajolovedek.Location.Y + urhajolovedek.Size.Height > pbEnemy.Location.Y 
                && urhajolovedek.Location.Y <= pbEnemy.Location.Y + pbEnemy.Size.Height 
                && pbEnemy.Visible && urhajolovedek.Location.X + urhajolovedek.Size.Width > pbEnemy.Location.X
                && urhajolovedek.Location.X <= pbEnemy.Location.X + pbEnemy.Size.Width)
            {
                pbEnemy.Visible = false;
                pontszam += 10;
                urhajolovedek.Location = new Point(pburhajo.Location.X + 20, pburhajo.Location.Y);
            }

            if (pontszam==100 && timer1.Enabled)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                MessageBox.Show("Gratulálok, nyertél!");
            }
        }
        private void lovedekell()
        {
            //űrhajó lövedék,

            enemyell(pbEnemy1);
            enemyell(pbEnemy2);
            enemyell(pbEnemy3);
            enemyell(pbEnemy4);
            enemyell(pbEnemy5);
            enemyell(pbEnemy6);
            enemyell(pbEnemy7);
            enemyell(pbEnemy8);
            enemyell(pbEnemy9);
            enemyell(pbEnemy10);

            label2.Text = pontszam.ToString();
        }
       
        private void timer2_Tick(object sender, EventArgs e)
        {
            //űrhajólövedék
        
            if (urhajolovedek.Location.Y > 0)
            {
                urhajolovedek.Location = new Point(urhajolovedek.Location.X, urhajolovedek.Location.Y - 10);
            }
            else 
            {
                urhajolovedek.Location = new Point(pburhajo.Location.X + 20, pburhajo.Location.Y);
            }
       
            lovedekell();
        }

        private void enemylovedekell(PictureBox enemylovedek, PictureBox pbEnemy, PictureBox pbEnemy2)
        {
            if (enemylovedek.Visible==false)
            {
                return;
            }
            if (enemylovedek.Location.Y + pburhajo.Size.Height > pburhajo.Location.Y
             && enemylovedek.Location.Y <= pburhajo.Location.Y + pburhajo.Size.Height
             && pburhajo.Location.X + pburhajo.Size.Width > enemylovedek.Location.X
             && pburhajo.Location.X <= enemylovedek.Location.X)
            {
                elet -= 1;
                enemylovedek.Location = new Point(pbEnemy.Location.X + 20, pbEnemy.Location.Y + 100);

            }
            else if (enemylovedek.Location.Y < this.Size.Height)
            {
                enemylovedek.Location = new Point(enemylovedek.Location.X, enemylovedek.Location.Y + 10);
            }
            else
            {
                if (pbEnemy.Visible)
                {
                    enemylovedek.Location = new Point(pbEnemy.Location.X + 20, pbEnemy.Location.Y + 100);
                }
                else if (pbEnemy2.Visible)
                {
                    enemylovedek.Location = new Point(pbEnemy2.Location.X + 20, pbEnemy2.Location.Y + 100);
                }
                else
                {
                    enemylovedek.Visible = false;
                }
                
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
           //enemy lövedék
            enemylovedekell(enemylovedek1, pbEnemy1, pbEnemy6);
            enemylovedekell(enemylovedek2, pbEnemy2, pbEnemy7);
            enemylovedekell(enemylovedek3, pbEnemy3, pbEnemy8);
            enemylovedekell(enemylovedek4, pbEnemy4, pbEnemy9);
            enemylovedekell(enemylovedek5, pbEnemy5, pbEnemy10);
            elet1.Visible = elet == 3;
            elet2.Visible = elet >= 2;
            elet3.Visible = elet >= 1;
            if (elet==0)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                MessageBox.Show("Vesztettél!", "Game Over");
            }
        }

    }
}
