﻿
namespace hazi_dolgozat_urhajosjatek
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.enemylovedek1 = new System.Windows.Forms.PictureBox();
            this.enemylovedek5 = new System.Windows.Forms.PictureBox();
            this.enemylovedek4 = new System.Windows.Forms.PictureBox();
            this.enemylovedek2 = new System.Windows.Forms.PictureBox();
            this.elet3 = new System.Windows.Forms.PictureBox();
            this.elet2 = new System.Windows.Forms.PictureBox();
            this.elet1 = new System.Windows.Forms.PictureBox();
            this.enemylovedek3 = new System.Windows.Forms.PictureBox();
            this.urhajolovedek = new System.Windows.Forms.PictureBox();
            this.pbEnemy1 = new System.Windows.Forms.PictureBox();
            this.pburhajo = new System.Windows.Forms.PictureBox();
            this.pbEnemy2 = new System.Windows.Forms.PictureBox();
            this.pbEnemy3 = new System.Windows.Forms.PictureBox();
            this.pbEnemy4 = new System.Windows.Forms.PictureBox();
            this.pbEnemy5 = new System.Windows.Forms.PictureBox();
            this.pbEnemy6 = new System.Windows.Forms.PictureBox();
            this.pbEnemy7 = new System.Windows.Forms.PictureBox();
            this.pbEnemy8 = new System.Windows.Forms.PictureBox();
            this.pbEnemy9 = new System.Windows.Forms.PictureBox();
            this.pbEnemy10 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urhajolovedek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pburhajo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy10)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(12, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Pontok:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(62, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // enemylovedek1
            // 
            this.enemylovedek1.BackColor = System.Drawing.Color.Transparent;
            this.enemylovedek1.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék21;
            this.enemylovedek1.Location = new System.Drawing.Point(246, 134);
            this.enemylovedek1.Name = "enemylovedek1";
            this.enemylovedek1.Size = new System.Drawing.Size(10, 62);
            this.enemylovedek1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemylovedek1.TabIndex = 21;
            this.enemylovedek1.TabStop = false;
            // 
            // enemylovedek5
            // 
            this.enemylovedek5.BackColor = System.Drawing.Color.Transparent;
            this.enemylovedek5.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék21;
            this.enemylovedek5.Location = new System.Drawing.Point(552, 134);
            this.enemylovedek5.Name = "enemylovedek5";
            this.enemylovedek5.Size = new System.Drawing.Size(10, 62);
            this.enemylovedek5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemylovedek5.TabIndex = 20;
            this.enemylovedek5.TabStop = false;
            // 
            // enemylovedek4
            // 
            this.enemylovedek4.BackColor = System.Drawing.Color.Transparent;
            this.enemylovedek4.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék21;
            this.enemylovedek4.Location = new System.Drawing.Point(471, 134);
            this.enemylovedek4.Name = "enemylovedek4";
            this.enemylovedek4.Size = new System.Drawing.Size(10, 62);
            this.enemylovedek4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemylovedek4.TabIndex = 19;
            this.enemylovedek4.TabStop = false;
            // 
            // enemylovedek2
            // 
            this.enemylovedek2.BackColor = System.Drawing.Color.Transparent;
            this.enemylovedek2.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék21;
            this.enemylovedek2.Location = new System.Drawing.Point(321, 134);
            this.enemylovedek2.Name = "enemylovedek2";
            this.enemylovedek2.Size = new System.Drawing.Size(10, 62);
            this.enemylovedek2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemylovedek2.TabIndex = 18;
            this.enemylovedek2.TabStop = false;
            // 
            // elet3
            // 
            this.elet3.BackColor = System.Drawing.Color.Transparent;
            this.elet3.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.elet1;
            this.elet3.Location = new System.Drawing.Point(755, 196);
            this.elet3.Name = "elet3";
            this.elet3.Size = new System.Drawing.Size(33, 28);
            this.elet3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.elet3.TabIndex = 17;
            this.elet3.TabStop = false;
            // 
            // elet2
            // 
            this.elet2.BackColor = System.Drawing.Color.Transparent;
            this.elet2.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.elet1;
            this.elet2.Location = new System.Drawing.Point(716, 196);
            this.elet2.Name = "elet2";
            this.elet2.Size = new System.Drawing.Size(33, 28);
            this.elet2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.elet2.TabIndex = 16;
            this.elet2.TabStop = false;
            // 
            // elet1
            // 
            this.elet1.BackColor = System.Drawing.Color.Transparent;
            this.elet1.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.elet1;
            this.elet1.Location = new System.Drawing.Point(677, 196);
            this.elet1.Name = "elet1";
            this.elet1.Size = new System.Drawing.Size(33, 28);
            this.elet1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.elet1.TabIndex = 15;
            this.elet1.TabStop = false;
            // 
            // enemylovedek3
            // 
            this.enemylovedek3.BackColor = System.Drawing.Color.Transparent;
            this.enemylovedek3.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék21;
            this.enemylovedek3.Location = new System.Drawing.Point(396, 134);
            this.enemylovedek3.Name = "enemylovedek3";
            this.enemylovedek3.Size = new System.Drawing.Size(10, 62);
            this.enemylovedek3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemylovedek3.TabIndex = 14;
            this.enemylovedek3.TabStop = false;
            // 
            // urhajolovedek
            // 
            this.urhajolovedek.BackColor = System.Drawing.Color.Transparent;
            this.urhajolovedek.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.lövedék3;
            this.urhajolovedek.Location = new System.Drawing.Point(388, 343);
            this.urhajolovedek.Name = "urhajolovedek";
            this.urhajolovedek.Size = new System.Drawing.Size(18, 18);
            this.urhajolovedek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.urhajolovedek.TabIndex = 11;
            this.urhajolovedek.TabStop = false;
            // 
            // pbEnemy1
            // 
            this.pbEnemy1.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy1.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy1.Location = new System.Drawing.Point(230, 12);
            this.pbEnemy1.Name = "pbEnemy1";
            this.pbEnemy1.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy1.TabIndex = 1;
            this.pbEnemy1.TabStop = false;
            // 
            // pburhajo
            // 
            this.pburhajo.BackColor = System.Drawing.Color.Transparent;
            this.pburhajo.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.spaceship_png_11552939090rdqw6ao42l;
            this.pburhajo.Location = new System.Drawing.Point(362, 367);
            this.pburhajo.Name = "pburhajo";
            this.pburhajo.Size = new System.Drawing.Size(74, 80);
            this.pburhajo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pburhajo.TabIndex = 0;
            this.pburhajo.TabStop = false;
            // 
            // pbEnemy2
            // 
            this.pbEnemy2.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy2.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy2.Location = new System.Drawing.Point(304, 12);
            this.pbEnemy2.Name = "pbEnemy2";
            this.pbEnemy2.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy2.TabIndex = 22;
            this.pbEnemy2.TabStop = false;
            // 
            // pbEnemy3
            // 
            this.pbEnemy3.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy3.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy3.Location = new System.Drawing.Point(377, 12);
            this.pbEnemy3.Name = "pbEnemy3";
            this.pbEnemy3.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy3.TabIndex = 23;
            this.pbEnemy3.TabStop = false;
            // 
            // pbEnemy4
            // 
            this.pbEnemy4.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy4.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy4.Location = new System.Drawing.Point(452, 12);
            this.pbEnemy4.Name = "pbEnemy4";
            this.pbEnemy4.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy4.TabIndex = 24;
            this.pbEnemy4.TabStop = false;
            // 
            // pbEnemy5
            // 
            this.pbEnemy5.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy5.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy5.Location = new System.Drawing.Point(526, 12);
            this.pbEnemy5.Name = "pbEnemy5";
            this.pbEnemy5.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy5.TabIndex = 25;
            this.pbEnemy5.TabStop = false;
            // 
            // pbEnemy6
            // 
            this.pbEnemy6.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy6.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy6.Location = new System.Drawing.Point(230, 76);
            this.pbEnemy6.Name = "pbEnemy6";
            this.pbEnemy6.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy6.TabIndex = 26;
            this.pbEnemy6.TabStop = false;
            // 
            // pbEnemy7
            // 
            this.pbEnemy7.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy7.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy7.Location = new System.Drawing.Point(304, 76);
            this.pbEnemy7.Name = "pbEnemy7";
            this.pbEnemy7.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy7.TabIndex = 27;
            this.pbEnemy7.TabStop = false;
            // 
            // pbEnemy8
            // 
            this.pbEnemy8.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy8.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy8.Location = new System.Drawing.Point(377, 76);
            this.pbEnemy8.Name = "pbEnemy8";
            this.pbEnemy8.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy8.TabIndex = 28;
            this.pbEnemy8.TabStop = false;
            // 
            // pbEnemy9
            // 
            this.pbEnemy9.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy9.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy9.Location = new System.Drawing.Point(452, 76);
            this.pbEnemy9.Name = "pbEnemy9";
            this.pbEnemy9.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy9.TabIndex = 29;
            this.pbEnemy9.TabStop = false;
            // 
            // pbEnemy10
            // 
            this.pbEnemy10.BackColor = System.Drawing.Color.Transparent;
            this.pbEnemy10.Image = global::hazi_dolgozat_urhajosjatek.Properties.Resources.letöltés1;
            this.pbEnemy10.Location = new System.Drawing.Point(526, 76);
            this.pbEnemy10.Name = "pbEnemy10";
            this.pbEnemy10.Size = new System.Drawing.Size(50, 46);
            this.pbEnemy10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnemy10.TabIndex = 30;
            this.pbEnemy10.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(116, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(594, 62);
            this.label3.TabIndex = 31;
            this.label3.Text = "Press [Enter] to start the game\r\nNyomja meg az [Enter] gombot az indításhoz";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbEnemy10);
            this.Controls.Add(this.pbEnemy9);
            this.Controls.Add(this.pbEnemy8);
            this.Controls.Add(this.pbEnemy7);
            this.Controls.Add(this.pbEnemy6);
            this.Controls.Add(this.pbEnemy5);
            this.Controls.Add(this.pbEnemy4);
            this.Controls.Add(this.pbEnemy3);
            this.Controls.Add(this.pbEnemy2);
            this.Controls.Add(this.enemylovedek1);
            this.Controls.Add(this.enemylovedek5);
            this.Controls.Add(this.enemylovedek4);
            this.Controls.Add(this.enemylovedek2);
            this.Controls.Add(this.elet3);
            this.Controls.Add(this.elet2);
            this.Controls.Add(this.elet1);
            this.Controls.Add(this.enemylovedek3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.urhajolovedek);
            this.Controls.Add(this.pbEnemy1);
            this.Controls.Add(this.pburhajo);
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "Form1";
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemylovedek3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urhajolovedek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pburhajo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnemy10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pburhajo;
        private System.Windows.Forms.PictureBox pbEnemy1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox urhajolovedek;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox enemylovedek3;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.PictureBox elet1;
        private System.Windows.Forms.PictureBox elet2;
        private System.Windows.Forms.PictureBox elet3;
        private System.Windows.Forms.PictureBox enemylovedek2;
        private System.Windows.Forms.PictureBox enemylovedek4;
        private System.Windows.Forms.PictureBox enemylovedek5;
        private System.Windows.Forms.PictureBox enemylovedek1;
        private System.Windows.Forms.PictureBox pbEnemy2;
        private System.Windows.Forms.PictureBox pbEnemy3;
        private System.Windows.Forms.PictureBox pbEnemy4;
        private System.Windows.Forms.PictureBox pbEnemy5;
        private System.Windows.Forms.PictureBox pbEnemy6;
        private System.Windows.Forms.PictureBox pbEnemy7;
        private System.Windows.Forms.PictureBox pbEnemy8;
        private System.Windows.Forms.PictureBox pbEnemy9;
        private System.Windows.Forms.PictureBox pbEnemy10;
        private System.Windows.Forms.Label label3;
    }
}

